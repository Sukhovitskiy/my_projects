﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomelessGame
{
    public partial class Form1 : Form
    {
        int j = 0,gym = 0, personal=0,bed=0,room=0,flat =0,wife=0;
        Random rand = new Random();
        Homeless homeless = new Homeless(10, 10, 10, 100);
        public Form1()
        {
            InitializeComponent();
        }
        private void counter()
        {
            j++;
            if (personal ==1)
            {
                if (homeless.Money >= 5000)//presonal
                {
                    homeless.Money = homeless.Money - 5000;
                    homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                    homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                    homeless.Health = homeless.Health + 700;
                    personal = 30;
                    textBox1.Text = homeless.About();
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    
                    label2.Text = j.ToString();
                }
                
            }
            if (personal!=0)
            {
               personal--;
            }
            if(gym==1)
            {
                if (homeless.Money >= 1000)//1000 evri month
                {
                    homeless.Money = homeless.Money - 1000;
                    homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                    homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                    homeless.Health = homeless.Health + 200;
                    gym = 30;

                    textBox1.Text = homeless.About();
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    
                    label2.Text = j.ToString();
                }
            }

            if(gym!=0)
            {
                gym--;
            }
            if (bed==1)
            {
                if (homeless.Money >= 300)
                {
                    homeless.Money = homeless.Money - 300;
                    homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                    homeless.Happiness = homeless.Happiness + 100;
                    homeless.Health = homeless.Health + rand.Next(-1, 1);
                    bed = 30;
                    textBox1.Text = homeless.About();
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    label2.Text = j.ToString();
                }
                else
                {
                    MessageBox.Show("You dont have enough money");
                }

            }
            if (bed!=0)
            {
                bed--;
            }
            if (room==1)
            {
                if (homeless.Money >= 1000)
                {
                    homeless.Money = homeless.Money - 1000;
                    homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                    homeless.Happiness = homeless.Happiness + 200;
                    homeless.Health = homeless.Health + rand.Next(-1, 1);
                    room = 30;
                    bed = 0;
                    textBox1.Text = homeless.About();
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    counter();

                    label2.Text = j.ToString();
                }
                else
                {
                    MessageBox.Show("You dont have enough money");
                }
            }
            if (room!=0)
            {
                room--;
            }
            if(flat==1)
            {
                if (homeless.Money >= 10000)
                {
                    homeless.Money = homeless.Money - 10000;
                    homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                    homeless.Happiness = homeless.Happiness + 400;
                    homeless.Health = homeless.Health + rand.Next(-1, 1);
                    room = 0;
                    bed = 0;
                    flat = 30;
                    textBox1.Text = homeless.About();
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    

                    label2.Text = j.ToString();
                }
                else
                {
                    MessageBox.Show("You dont have enough money");
                }
            }
            if (flat!=0)
            {
                flat--;
            }
            if(wife==1)
            {
                if (homeless.Money >= 100000)
                {
                    if (rand.Next(1, 4) == 1)
                    {
                        MessageBox.Show("She said no and stole your money");
                        homeless.Money = homeless.Money - 10000;
                        return;
                    }

                    homeless.Money = homeless.Money - 10000;
                    homeless.Hunger = homeless.Hunger + 200;
                    homeless.Happiness = homeless.Happiness + rand.Next(1, 5);
                    homeless.Health = homeless.Health + rand.Next(0, 3);
                    textBox1.Text = homeless.About();
                    wife = 30;
                    if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                    {
                        MessageBox.Show("You lost");
                        j = 0;
                        homeless.Hunger = 10;
                        homeless.Happiness = 10;
                        homeless.Health = 10;
                        homeless.Money = 10;
                    }
                    
                    label2.Text = j.ToString();
                }
                else
                {
                    MessageBox.Show("You dont have enough money");
                }
                
            }
            if(wife!=0)
            {
                    wife--;
            }
            if (homeless.Driving == true)
                {
                    textBox2.Text = "Driving licence : Goten ";
                }
            if (homeless.Master==true)
            {
                textBox2.Text = "Education level : Master(University) ";
            }         
            else if (homeless.Clerk == true)
            {
                textBox2.Text = "Education level : Clerk(University) ";
            } 
            else if(homeless.Finish11 == true)
            {
                textBox2.Text = "Education level : 11(School) ";
            }
            else if (homeless.Finish9 == true)
            {
                textBox2.Text = "Education level : 9(School) ";
            }
            else if (homeless.Finish4 == true)
            {
                textBox2.Text = "Education level : 4(School) ";
            }
            else
            {
                textBox2.Text = "You dont have an education level ";
            }   
            if (wife!=0)
            {
                textBox2.Text = textBox2.Text +"You have a wife ";
            }           
            if (bed !=0)
            {
                textBox2.Text = textBox2.Text +"You have a bed ";
            }
            if (room!=0)
            {
                textBox2.Text = textBox2.Text +  "You have a bed ";
            }
            if (flat!=0)
            {
                textBox2.Text = textBox2.Text +  "You have a flat ";
            }
            if (gym != 0)
            {
                textBox2.Text = textBox2.Text +  "You have a gym subscription ";
            }
            if (personal != 0)
            {
                textBox2.Text = textBox2.Text +  "You have a personal trainer ";
            }
        }

        private void button1_Click(object sender, EventArgs e)//Eat food
        {

            homeless.Hunger = homeless.Hunger + rand.Next(2, 6);
            homeless.Happiness = homeless.Happiness + rand.Next(-3, 0);
            homeless.Health = homeless.Health + rand.Next(-2, 1);
            textBox1.Text = homeless.About();
            if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
            {
                MessageBox.Show("You lost");
                j = 0;
                homeless.Hunger = 10;
                homeless.Happiness = 10;
                homeless.Health = 10;
                homeless.Money = 10;
            }
            counter();
            label2.Text = j.ToString();
        }
        private void button2_Click(object sender, EventArgs e)//Hapiness
        {
            homeless.Hunger = homeless.Hunger + rand.Next(-2, 0);
            homeless.Happiness = homeless.Happiness + rand.Next(2, 6);
            homeless.Health = homeless.Health + rand.Next(-1, 1);
            textBox1.Text = homeless.About();
            if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
            {
                MessageBox.Show("You lost");
                j = 0;
                homeless.Hunger = 10;
                homeless.Happiness = 10;
                homeless.Health = 10;
                homeless.Money = 10;
            }
            counter();

            label2.Text = j.ToString();
        }
        private void button3_Click(object sender, EventArgs e)//Meds
        {
            homeless.Hunger = homeless.Hunger + rand.Next(-2, 0);
            homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
            homeless.Health = homeless.Health + rand.Next(2, 6);
            textBox1.Text = homeless.About();
            if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
            {
                MessageBox.Show("You lost");
                j = 0;
                homeless.Hunger = 10;
                homeless.Happiness = 10;
                homeless.Health = 10;
                homeless.Money = 10;
            }
            counter();

            label2.Text = j.ToString();
        }

        private void button4_Click(object sender, EventArgs e)//Money/beg
        {
            homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
            homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
            homeless.Health = homeless.Health + rand.Next(-2, 0);
            homeless.Money = homeless.Money + rand.Next(0, 5);
            textBox1.Text = homeless.About();
            if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
            {
                MessageBox.Show("You lost");
                j = 0;
                homeless.Hunger = 10;
                homeless.Happiness = 10;
                homeless.Health = 10;
                homeless.Money = 10;
            }
            counter();

            label2.Text = j.ToString();
        }

        private void button5_Click(object sender, EventArgs e)//hotdog(food)
        {
            if (homeless.Money >= 10)
            {
                homeless.Money = homeless.Money - 10;
                homeless.Hunger = homeless.Hunger + 15;
                homeless.Happiness = homeless.Happiness + rand.Next(1, 5);
                homeless.Health = homeless.Health + rand.Next(0, 3);
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button6_Click(object sender, EventArgs e)//cafe(food)
        {
            if (homeless.Money >= 200)
            {
                homeless.Money = homeless.Money - 200;
                homeless.Hunger = homeless.Hunger + 65;
                homeless.Happiness = homeless.Happiness + rand.Next(-3, 0);
                homeless.Health = homeless.Health + rand.Next(-2, 1);
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }

        }

        private void button7_Click(object sender, EventArgs e)//restaurante(food)
        {
            if (homeless.Money >= 1000)
            {
                homeless.Money = homeless.Money - 1000;
                homeless.Hunger = homeless.Hunger + 120;
                homeless.Happiness = homeless.Happiness + rand.Next(-3, 0);
                homeless.Health = homeless.Health + rand.Next(-2, 1);
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button18_Click(object sender, EventArgs e)//janitor(work)
        {
            if (homeless.Finish4 == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 15;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You dont have the correct education level(Required level : 4");
            }

        }

        private void button19_Click(object sender, EventArgs e)//loader(work)
        {
            if (homeless.Finish9 == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 50;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You dont have the correct education level(Required level : 9");
            }
        }

        private void button20_Click(object sender, EventArgs e)//retail(work)
        {
            if (homeless.Finish11 == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 200;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You dont have the correct education level(Required level : 11");
            }
        }

        private void button21_Click(object sender, EventArgs e)//driving (work)
        {
            if (homeless.Driving == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 350;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You dont have a driving licence");
            }
        }

        private void button22_Click(object sender, EventArgs e)//washing service(work)
        {
            if (homeless.Clerk == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 550;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You must be a clerk");
            }
        }

        private void button23_Click(object sender, EventArgs e)//rest(work)
        {
            if (homeless.Master == true)
            {
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-1, 1);
                homeless.Health = homeless.Health + rand.Next(-2, 0);
                homeless.Money = homeless.Money + 1000;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }

            else
            {
                MessageBox.Show("You must have a master's degree");
            }
        }

        private void button24_Click(object sender, EventArgs e)//education lvl 4
        {
            if (homeless.Money>=100)
            {
                homeless.Finish4 = true;
                homeless.Money = homeless.Money - 100;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
            
        }

        private void button25_Click(object sender, EventArgs e)//eductaion lvl 9
        {
            if (homeless.Money >= 500)
            {
                homeless.Finish9 = true;
                homeless.Money = homeless.Money - 500;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }

        }

        private void button26_Click(object sender, EventArgs e)//education lvl 11
        {
            if (homeless.Money >= 2000)
            {
                homeless.Finish11 = true;
                homeless.Money = homeless.Money - 2000;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button27_Click(object sender, EventArgs e)//driving
        {
            if (homeless.Money >= 5000)
            {
                homeless.Driving = true;
                homeless.Money = homeless.Money - 5000;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button28_Click(object sender, EventArgs e)//clerk
        {
            if (homeless.Money >= 20000)
            {
                homeless.Clerk = true;
                homeless.Money = homeless.Money - 20000;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button29_Click(object sender, EventArgs e)//master
        {
            if (homeless.Money >= 50000)
            {
                homeless.Master = true;
                homeless.Money = homeless.Money - 50000;
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button9_Click(object sender, EventArgs e)//box
        {
            if (homeless.Money >= 100)
            {
                homeless.Money = homeless.Money - 100;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + 50;
                homeless.Health = homeless.Health + rand.Next(-1, 1);
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
            
        }

        private void button13_Click(object sender, EventArgs e)//shoes nerf dem
        {
            if (homeless.Money >= 300)
            {
                homeless.Money = homeless.Money - 300;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                homeless.Health = homeless.Health + 150;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button14_Click(object sender, EventArgs e)//cloths
        {
            if (homeless.Money >= 500)
            {
                homeless.Money = homeless.Money - 500;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                homeless.Health = homeless.Health + 350;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button15_Click(object sender, EventArgs e)//pharmacy
        {
            if (homeless.Money >= 200)
            {
                homeless.Money = homeless.Money - 200;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                homeless.Health = homeless.Health + 100;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        

        private void button8_Click(object sender, EventArgs e)//marry
        {
            
            if (homeless.Money >= 100000)
            {
                if (rand.Next(1,5)==1)
                {
                    MessageBox.Show("She said no and stole your money");
                    homeless.Money = homeless.Money - 100000;
                    return;
                }

                homeless.Money = homeless.Money - 100000;
                homeless.Hunger = homeless.Hunger + 200;
                homeless.Happiness = homeless.Happiness + rand.Next(1, 5);
                homeless.Health = homeless.Health + rand.Next(0, 3);
                textBox1.Text = homeless.About();
                wife = 30;
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button12_Click(object sender, EventArgs e)//rent a flat
        {
            if (homeless.Money >= 10000)
            {
                homeless.Money = homeless.Money - 10000;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + 400;
                homeless.Health = homeless.Health + rand.Next(-1, 1);
                room = 0;
                bed = 0;
                flat = 30;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }
    

        private void button11_Click(object sender, EventArgs e)//rent a room
        {
            if (homeless.Money >= 1000)
            {
                homeless.Money = homeless.Money - 1000;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + 200;
                homeless.Health = homeless.Health + rand.Next(-1, 1);
                room = 30;
                bed = 0;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button10_Click(object sender, EventArgs e)//rent a bed
        {
            if (homeless.Money >= 300)
            {
                homeless.Money = homeless.Money - 300;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + 100;
                homeless.Health = homeless.Health + rand.Next(-1, 1);
                bed = 30;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();
                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button17_Click(object sender, EventArgs e)//5000 personmal
        {
            if (homeless.Money >= 5000)
            {
                homeless.Money = homeless.Money - 5000;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                homeless.Health = homeless.Health + 700;
                personal = 30;
                gym = 0;
                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }

        private void button16_Click(object sender, EventArgs e)//gym
        {
            if (homeless.Money >= 1000)//1000 evri month
            {
                homeless.Money = homeless.Money - 1000;
                homeless.Hunger = homeless.Hunger + rand.Next(-3, 0);
                homeless.Happiness = homeless.Happiness + rand.Next(-2, 1);
                homeless.Health = homeless.Health + 200;
                gym = 30;

                textBox1.Text = homeless.About();
                if (homeless.Hunger < 0 || homeless.Happiness < 0 || homeless.Health < 0)
                {
                    MessageBox.Show("You lost");
                    j = 0;
                    homeless.Hunger = 10;
                    homeless.Happiness = 10;
                    homeless.Health = 10;
                    homeless.Money = 10;
                }
                counter();

                label2.Text = j.ToString();
            }
            else
            {
                MessageBox.Show("You dont have enough money");
            }
        }
    }
}
