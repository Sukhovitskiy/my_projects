﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomelessGame
{
    class Homeless
    {
        int health;
        int hunger;
        int happiness;
        int money;
        bool finish4 = false;
        bool finish9 = false;
        bool finish11 = false;
        bool driving = false;
        bool clerk = false;
        bool master = false;


        public Homeless(int health1, int hunger1, int happiness1, int money1)
        {
            health = health1;
            hunger = hunger1;
            happiness = happiness1;
            money = money1;
        }

        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = value;
            }

        }
        public int Hunger
        {
            get
            {
                return hunger;
            }
            set
            {
                hunger = value;
            }

        }
        public int Happiness
        {
            get
            {
                return happiness;
            }
            set
            {
                happiness = value;
            }
        }
        public int Money
        {
            get
            {
                return money;
            }
            set
            {
                money = value;
            }

        }
        public bool Finish4
        {
            get
            {
                return finish4;
            }
            set
            {
                finish4 = value;
            }
        
        }
        public bool Finish9
        {
            get
            {
                return finish9;
            }
            set
            {
                finish9 = value;
            }

        }
        public bool Finish11
        {
            get
            {
                return finish11;
            }
            set
            {
                finish11 = value;
            }

        }
        public bool Driving
        {
            get
            {
                return driving;
            }
            set
            {
                driving = value;
            }

        }
        public bool Clerk
        {
            get
            {
                return clerk;
            }
            set
            {
                clerk = value;
            }

        }
        public bool Master
        {
            get
            {
                return master;
            }
            set
            {
                master = value;
            }

        }

        public string About()
        {
           return $"Health : {health}, Hunger : {hunger}, Happiness : {happiness}, Money : {money} ";
        }
    }
}
